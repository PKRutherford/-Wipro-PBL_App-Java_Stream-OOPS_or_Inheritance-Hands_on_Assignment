public class author
{
	String name;
	String email;
	char gender;
	
	author (String name, String email, char gender)
	{
		this.name = name;
		this.email = email;
		this.gender = gender;
	}
}