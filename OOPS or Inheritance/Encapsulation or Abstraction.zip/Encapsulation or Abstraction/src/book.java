public class book
{
	String name;
	double price;
	int qtyInStock;
	author Author;
	
	book(String name, double price, int qtyInStock)
	{
		this.name = name;
		this.price = price;
		this.qtyInStock = qtyInStock;
	}
	public String getname()
	{
		return name;
	}
	public double getprice()
	{
		return price;
	}
	public int getqtyInStock()
	{
		return qtyInStock;
	}
	public void setname(String name)
	{
		this.name = name;
	}
	public void setprice(double price)
	{
		this.price = price;
	}
	public void setqtyInStock(int qtyInStock)
	{
		this.qtyInStock = qtyInStock;
	}
	public static void main(String[] args)
	{
		book details = new book ("abcdef",100,20);
		System.out.println("Book Name :- "+details.getname());
		System.out.println("Book Price :- "+details.getprice());
		System.out.println("Book Quantity :- "+details.getqtyInStock());
	}
}