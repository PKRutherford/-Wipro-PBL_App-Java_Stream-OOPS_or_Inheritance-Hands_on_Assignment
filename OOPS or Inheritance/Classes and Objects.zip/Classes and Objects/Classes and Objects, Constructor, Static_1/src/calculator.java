public class calculator
{
	public static double powerInt(int num1, int num2)
	{
		return Math.pow(num1,num2);
	}
	public static double powerDouble(double num1, double num2)
	{
		return Math.pow(num1,num2);
	}
	public static void main(String[] args)
	{
		System.out.println("The output is :- "+calculator.powerInt(2,3));
		System.out.println("The output is :- "+calculator.powerDouble(3,2));
	}
}