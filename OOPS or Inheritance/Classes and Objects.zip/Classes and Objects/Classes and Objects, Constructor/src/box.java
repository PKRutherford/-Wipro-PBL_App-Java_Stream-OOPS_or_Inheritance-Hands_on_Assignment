public class box
{
	double width,height,depth;
	
	public void boxwidth(double boxwidth)
	{
		width = boxwidth;	
	}
	public void boxheight(double boxheight)
	{
		height = boxheight;	
	}
	public void boxdepth(double boxdepth)
	{
		depth = boxdepth;	
	}
	public double vol()
	{
		double vol = width*height*depth;
		return vol;
	}
	public void printbox()
	{
		System.out.println("Width  :- "+width);
		System.out.println("Height :- "+height);
		System.out.println("Depth  :- "+depth);
	}
	public static void main(String[] args)
	{
		box object = new box ();
		object.boxwidth(2);
		object.boxheight(3);
		object.boxdepth(6);
		object.printbox();
		double vol = object.vol();
		System.out.println("The volume of the box is :- "+vol);
	}
}