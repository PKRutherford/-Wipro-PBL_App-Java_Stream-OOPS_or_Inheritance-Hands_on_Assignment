public class patient
{
	String patientname;
	double height;
	double weight; /* In the given question they have given as width so change
					  it to weight
					*/
	patient (String patientname, double height,double weight)
	{
		this.patientname = patientname;
		this.height = height;
		this.weight = weight;
		
	}
	public double computeBMI()
	{
		double BMI;
		BMI = weight + height*height;
		return BMI;
	}
	public static void main(String[] args)
	{
		patient details = new patient("abcdef", 1.2, 59);
		System.out.println("The Patient BMI is :- "+details.computeBMI());
	}
}