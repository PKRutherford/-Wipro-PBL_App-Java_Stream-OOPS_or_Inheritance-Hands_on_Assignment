public class person
{
	String name;
	String dateofbirth;
	
	person (String name, String dob)
	{
		this.name = name;
		this.dateofbirth = dob;
	}
}