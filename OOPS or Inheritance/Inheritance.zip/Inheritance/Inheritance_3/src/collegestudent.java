public class collegestudent extends student
{
	String collegename;
	String year;
	collegestudent(String name, String dob, String collegename, String year, String studentid)
	{
		super(studentid,name,dob);
		this.collegename = collegename;
		this.year = year;
	}
	
	public void printcollegestudent()
	{
		System.out.println("The College Student Name is :- "+name);
		System.out.println("The College Student ID is :- "+studentid);
		System.out.println("The College Student College Name is :- "+collegename);
		System.out.println("The College Student Date of Birth is :- "+dateofbirth);
		System.out.println("The College student Year of Study is :- "+year);
	}
}