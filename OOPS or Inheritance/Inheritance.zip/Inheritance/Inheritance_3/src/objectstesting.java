public class objectstesting
{
	public static void main(String[] args)
	{
		teacher object1 = new teacher("abcdef", "xx-xx-xxxx", 10000, "All_Subjects");
		object1.printteacher();
		student object2 = new student("abcdef", "xx-xx-xxxx", "12x11x0111");
		object2.printstudent();
		collegestudent object3 = new collegestudent("abcdef", "xx-xx-xxxx", "xyz_college", "fourth", "12x11x0111" );
		object3.printcollegestudent();
	}
}