public class teacher extends person
{
	double salary;
	String Subject;
	teacher(String name, String dob, double salary, String subject)
	{
		super(name,dob);
		this.salary = salary;
		this.Subject = subject;
	}
	
	public void printteacher()
	{
		System.out.println("The Teacher Name is :- "+name);
		System.out.println("The Teacher Date Of Birth is :- "+dateofbirth);
		System.out.println("The Teacher Teaching Subject is :- "+Subject);
		System.out.println("The Teacher Salary is :- "+salary);
	}
}