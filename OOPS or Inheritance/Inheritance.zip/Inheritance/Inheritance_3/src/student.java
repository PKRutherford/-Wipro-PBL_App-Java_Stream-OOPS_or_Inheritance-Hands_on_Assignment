public class student extends person
{
	String studentid;
	student(String name, String dob,String studentid)
	{
		super(name,dob);
		this.studentid = studentid;
	}
	
	public void printstudent()
	{
		System.out.println("The Student Name is :- "+name);
		System.out.println("The Student Date Of Birth is :- "+dateofbirth);
		System.out.println("The Student ID is :- "+studentid);
	}
}