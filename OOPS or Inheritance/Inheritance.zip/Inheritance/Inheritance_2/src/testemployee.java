public class testemployee
{
	employee employee;
	public static void main(String[] args)
	{
		employee details = new employee ("abcdef",10000,2020,"wipro-123456");
		details.print();		
	}
}