public class person
{
	String name;
	person(String name)
	{
		this.name = name;
	}
}