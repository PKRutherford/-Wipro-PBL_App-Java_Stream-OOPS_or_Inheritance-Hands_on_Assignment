
public class employee extends person
{
	double annual_salary;
	int year;
	String insurance_number;
	employee (String name, double annual_salary, int year, String insurance_number)
	{
		super(name);
		this.annual_salary = annual_salary;
		this.year = year;
		this.insurance_number = insurance_number;
	}
	public void print()
	{
		System.out.println("Employee name is :- "+name);
		System.out.println("Employee Annual Salary :- "+annual_salary);
		System.out.println("Joining Year :- "+year);
		System.out.println("Insurance Number :- "+insurance_number);
	}
}