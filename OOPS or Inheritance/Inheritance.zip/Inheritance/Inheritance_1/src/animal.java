public class animal
{
	public void eat()
	{
		System.out.println("The animal eat");
	}
	public void sleep()
	{
		System.out.println("The animal sleep");
	}
}