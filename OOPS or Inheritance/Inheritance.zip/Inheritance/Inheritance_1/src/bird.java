public class bird
{
	public void fly()
	{
		System.out.println("The bird fly");
	}
	public void eat()
	{
		System.out.println("The bird eat");
	}
	public void sleep()
	{
		System.out.println("The bird sleep");
	}
	public static void main(String[] args)
	{
		animal detail1 = new animal();
		bird detail2 = new bird();
		detail1.eat();
		detail1.sleep();
		detail2.eat();
		detail2.sleep();
		detail2.fly();
	}
}